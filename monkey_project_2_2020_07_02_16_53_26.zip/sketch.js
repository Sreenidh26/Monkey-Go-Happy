var wallpaperImage,wallpaper;
var player, player_running;
var ground,ground_img;

var backgroundSound
var bananaSound
var gameOverSound

var bananaGroup,banana, bananaImage;
var obstaclesGroup, obstacle_img;

var gameOver, gameOverImage;
var restart, restartImage;
var score=0;


function preload(){
  wallpaperImage=loadImage("jungle2.jpg");
  player_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  //background music 
  backgroundSound=loadSound("African_fun_long.mp3")
  
  //banana music
  bananaSound=loadSound("zapsplat_multimedia_game_sound_coins_collect_several_at_once_002_40813.mp3");
  
  //game over music
  gameOverSound=loadSound("esm_8_bit_game_over_1_arcade_80s_simple_alert_notification_game.mp3");

  //loading images for restarting,banana,obstacles
  gameOverImage = loadImage("gameOver.png");
  restartImage = loadImage("restart.png");
  bananaImage = loadImage("Banana.png");
  obstacle_img = loadImage("stone.png"); 
  
}

function setup() {
  createCanvas(800,400);
  
  //background sound plays throughout the game
  backgroundSound.play();
  
  //wallpaper
  wallpaper=createSprite(0,0,800,400);
  wallpaper.addImage(wallpaperImage);
  wallpaper.scale=1.5;
  wallpaper.x=wallpaper.width/2;
  wallpaper.velocityX=-4;
  
  //paper
  player = createSprite(100,340,20,50);
  player.addAnimation("Running",player_running);
  player.scale = 0.1;
  
  //ground
  ground = createSprite(400,350,800,10);
  ground.velocityX=-4;
  ground.x=ground.width/2;
  ground.visible=false;
  
  //game over
  gameOver = createSprite(300,150,20,20);
  gameOver.addImage(gameOverImage);
  gameOver.visible=false
  
  //restart
  restart = createSprite(300,250,20,20);
  restart.addImage(restartImage);
  restart.visible=false;
  
  //groups for banana and obstacle
  bananaGroup = new Group();
  obstaclesGroup = new Group();
  
  //score
  score = 0;
}

function draw() {
  
  background(255);
  
  //ground and background moving 
  if(ground.x<0) {
    ground.x=ground.width/2;
  }
  if(wallpaper.x<100){
    wallpaper.x=wallpaper.width/2;
  }
  
  //if banana group is touching player music plays and the banana destroys
    if(bananaGroup.isTouching(player)){
      bananaGroup.destroyEach();
      bananaSound.play();
    score = score + 2;
      //monkey grows when score increases
    }
    switch(score){
        case 10: player.scale=0.2;
                break;
        case 20: player.scale=0.25;
                break;
        case 30: player.scale=0.3;
                break;
        case 40: player.scale=0.35;
                break;
        default: break;
    }
  
  //pressing space will make monkey jump
    if(keyDown("space")&& player.collide(ground) ) {
      player.velocityY = -15   ;
    }
    player.velocityY = player.velocityY + 0.8;
  
  //player collides with ground so monkey doesnt fall
    player.collide(ground);
  
  //makes it so banana and rock will be invisible when game ends
    if(gameOver.visible==false)
    {
    spawnFood();
    spawnObstacles();
    }
  //game over commands
    if(obstaclesGroup.isTouching(player)){ 
        backgroundSound.stop();
        gameOverSound.play();
        player.visible=false
        wallpaper.velocityX = 0;
        obstaclesGroup.destroyEach();
        bananaGroup.destroyEach();
        player.velocityX = 0;
        player.velocityY = 0;
        bananaGroup.setLifetimeEach(-1);
        obstaclesGroup.setLifetimeEach(-1);
        obstaclesGroup.scale=0.000001; 
        bananaGroup.scale=0.00001;
        gameOver.visible=true;
        restart.visible=true;
     
    }
  
  //restart command
  if(mousePressedOver(restart)) 
  {
    player.visible=true
    gameOver.visible=false
    restart.visible=false
    wallpaper.velocityX=-4;
    backgroundSound.play();
    if(ground.x<0) {
    ground.x=ground.width/2;
  }
  if(wallpaper.x<100){
    wallpaper.x=wallpaper.width/2;
  }
  
    if(bananaGroup.isTouching(player)){
      bananaGroup.destroyEach();
      bananaSound.play();
    score = score + 2;
    }
    switch(score){
        case 10: player.scale=0.2;
                break;
        case 20: player.scale=0.3;
                break;
        case 30: player.scale=0.4;
                break;
        case 40: player.scale=0.5;
                break;
        default: break;
    }
  
    if(keyDown("space") ) {
      player.velocityY = -12;
    }
    player.velocityY = player.velocityY + 0.8;
  
    player.collide(ground);
    spawnFood();
    spawnObstacles();
  }
  
  drawSprites();
  
  //score text
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500,50);
}
//function for spawning in food
function spawnFood() {
  //write code here to spawn the food
  if (frameCount % 80 === 0) {
    var banana = createSprite(600,250,40,10);
    banana.y = random(120,200);    
    banana.addImage(bananaImage);
    banana.scale = 0.05;
    banana.velocityX = -5;
     //assign lifetime to the variable
    banana.lifetime = 300;
    player.depth = banana.depth + 1;
    
    //add each banana to the group
    bananaGroup.add(banana);
  }
}

//function for spawning obstacles
function spawnObstacles() {
  if(frameCount % 300 === 0) {
    var obstacle = createSprite(460,350,10,40);
    obstacle.velocityX = -6;
    obstacle.addImage(obstacle_img);
    
    //obstacle scale lifetime and adding obstacle to obstacle group     
    obstacle.scale = 0.2;
    obstacle.lifetime = 300;
    
    
    obstaclesGroup.add(obstacle);
  }
}


  
